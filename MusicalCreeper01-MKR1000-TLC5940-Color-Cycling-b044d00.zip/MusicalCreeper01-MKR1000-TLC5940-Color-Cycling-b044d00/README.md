# MKR1000-TLC5940-Color-Cycling
Created for https://www.hackster.io/challenges/arduino-microsoft-maker using my MKR1000 TLC5940 Library

Using this library for hsv to rgb: https://github.com/ratkins/RGBConverter
